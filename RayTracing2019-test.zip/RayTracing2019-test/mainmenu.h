#ifndef MAINMENU_H
#define MAINMENU_H


class MainMenu
{
public:
    MainMenu();
};

#endif // MAINMENU_H
