# raytracing


In this version you can place one transmiter and one receiver and measure the distance between both by clicking on Launch Ray-Traicing. 
To put the transmiter/receiver you have to click on the coresponding icon and then click somwhere on the blank widget. 
